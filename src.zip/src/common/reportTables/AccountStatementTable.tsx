"use client";

import { DataTable } from "@/components/ui/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import { formatStatementAmount } from "@/container/mis-reports/monthly-statement-of-accounts/MonthlyStatementApi";
import type { MonthlyStatementRow } from "@/container/mis-reports/monthly-statement-of-accounts/MonthlyStatementType";

const amount = (value: unknown) => formatStatementAmount(Number(value) || 0);

const columns: ColumnDef<MonthlyStatementRow>[] = [
  { accessorKey: "accountCode", header: "Code" },
  { accessorKey: "accountName", header: "Account Name" },
  { accessorKey: "category", header: "Category" },
  { accessorKey: "openingDebit", header: "Opening Debit", cell: ({ getValue }) => amount(getValue()) },
  { accessorKey: "openingCredit", header: "Opening Credit", cell: ({ getValue }) => amount(getValue()) },
  { accessorKey: "debit", header: "Debit", cell: ({ getValue }) => amount(getValue()) },
  { accessorKey: "credit", header: "Credit", cell: ({ getValue }) => amount(getValue()) },
  { accessorKey: "closingDebit", header: "Closing Debit", cell: ({ getValue }) => amount(getValue()) },
  { accessorKey: "closingCredit", header: "Closing Credit", cell: ({ getValue }) => amount(getValue()) },
];

const AccountStatementTable = ({ rows }: { rows: MonthlyStatementRow[] }) => (
  <DataTable
    columns={columns}
    data={rows}
  />
);

export default AccountStatementTable;
