"use client";

import { DataTable } from "@/components/ui/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import type { LoanPortfolioRow } from "@/container/mis-reports/loan-portfolio/LoanPortfolioType";

const money = (value: unknown) => new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(Number(value) || 0);
const pct = (value: unknown) => `${Number(value || 0).toFixed(2)}%`;
const columns: ColumnDef<LoanPortfolioRow>[] = [
  { accessorKey: "name", header: "Branch / Sahayika" }, { accessorKey: "code", header: "Code" },
  { accessorKey: "activeGroups", header: "Groups" }, { accessorKey: "activeMembers", header: "Members" }, { accessorKey: "activeLoans", header: "Active Loans" },
  { accessorKey: "disbursedAmount", header: "Disbursed", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "outstanding", header: "Outstanding", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "demand", header: "Demand", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "collection", header: "Collection", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "collectionPercent", header: "Coll. %", cell: ({ getValue }) => pct(getValue()) },
  { accessorKey: "overdueAmount", header: "Overdue", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "parPercent", header: "PAR %", cell: ({ getValue }) => pct(getValue()) },
];
const LoanPortfolioTable = ({ rows }: { rows: LoanPortfolioRow[] }) => <DataTable columns={columns} data={rows} />;
export default LoanPortfolioTable;
