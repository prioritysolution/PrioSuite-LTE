"use client";

import { DataTable } from "@/components/ui/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import type { ReceiptPaymentScrollRow } from "@/container/mis-reports/receipt-payment-scroll/ReceiptPaymentScrollType";

const money = (value: unknown) =>
  new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(value) || 0);

const columns: ColumnDef<ReceiptPaymentScrollRow>[] = [
  { accessorKey: "date", header: "Date" },
  { accessorKey: "voucherNo", header: "Voucher No." },
  { accessorKey: "voucherType", header: "Type" },
  { accessorKey: "sahayikaName", header: "Sahayika" },
  { accessorKey: "particulars", header: "Particulars" },
  { accessorKey: "accountName", header: "Account" },
  { accessorKey: "mode", header: "Mode" },
  { accessorKey: "receiptAmount", header: "Receipt", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "paymentAmount", header: "Payment", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "runningBalance", header: "Balance", cell: ({ getValue }) => money(getValue()) },
];

const ReceiptPaymentScrollTable = ({ rows }: { rows: ReceiptPaymentScrollRow[] }) => (
  <DataTable
    columns={columns}
    data={rows}
  />
);

export default ReceiptPaymentScrollTable;
