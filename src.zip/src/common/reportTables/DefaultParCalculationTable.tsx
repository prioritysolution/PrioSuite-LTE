"use client";

import { DataTable } from "@/components/ui/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import type { DefaultParCalculationRow } from "@/container/mis-reports/default-par-calculation/DefaultParCalculationType";

const money = (value: unknown) =>
  new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(Number(value) || 0);
const pct = (value: unknown) => `${Number(value || 0).toFixed(2)}%`;

const columns: ColumnDef<DefaultParCalculationRow>[] = [
  { accessorKey: "name", header: "Branch / Sahayika" },
  { accessorKey: "code", header: "Code" },
  { accessorKey: "activeLoans", header: "Active Loans" },
  { accessorKey: "outstanding", header: "Outstanding", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "par1To30", header: "1-30 Days", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "par31To60", header: "31-60 Days", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "par61To90", header: "61-90 Days", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "parAbove90", header: "90+ Days", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "parAmount", header: "PAR Amount", cell: ({ getValue }) => money(getValue()) },
  { accessorKey: "parPercent", header: "PAR %", cell: ({ getValue }) => pct(getValue()) },
];

const DefaultParCalculationTable = ({ rows }: { rows: DefaultParCalculationRow[] }) => (
  <DataTable columns={columns} data={rows} />
);

export default DefaultParCalculationTable;
