"use client";

import { Download, FileSpreadsheet, Loader2, Printer } from "lucide-react";
import { useReactToPrint } from "react-to-print";
import { useRef } from "react";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import MisReportFilter, { MIS_REPORT_PRESETS } from "@/common/reportFilters/MisReportFilter";
import AccountStatementTable from "@/common/reportTables/AccountStatementTable";
import type { MonthlyStatementProps } from "@/container/mis-reports/monthly-statement-of-accounts/MonthlyStatementType";
import { formatStatementAmount, formatStatementDate } from "@/container/mis-reports/monthly-statement-of-accounts/MonthlyStatementApi";

const exportCsv = (report: NonNullable<MonthlyStatementProps["report"]>) => {
  const lines = [
    ["Account Code", "Account Name", "Category", "Opening Debit", "Opening Credit", "Debit", "Credit", "Closing Debit", "Closing Credit"],
    ...report.rows.map((row) => [row.accountCode, row.accountName, row.category, row.openingDebit, row.openingCredit, row.debit, row.credit, row.closingDebit, row.closingCredit]),
  ];
  const csv = lines.map((line) => line.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `monthly-statement-of-accounts-${report.summary.fromDate}-to-${report.summary.toDate}.csv`;
  link.click();
  URL.revokeObjectURL(url);
};

const MonthlyStatementComponent = (props: MonthlyStatementProps) => {
  const { form, loading, isHead, branchName, branchOptions, branchLoading, report, onShow, onPreset, activePreset } = props;
  const printRef = useRef<HTMLDivElement>(null);
  const handlePrint = useReactToPrint({ contentRef: printRef, pageStyle: "@page { size: A4 landscape; margin: 8mm; }" });
  const summary = report?.summary;
  return (
    <>
      <div className="page-content print:hidden">
        <div className="page-header-card">
          <div className="absolute top-0 left-0 h-full w-1.5 bg-primary" />
          <div className="flex min-w-0 items-start gap-3 pl-2 sm:gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary text-white shadow-sm"><FileSpreadsheet size={24} /></div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-500">MIS Report <span className="text-gray-300">›</span> Monthly Statement of Accounts</p>
              <h2 className="text-2xl font-bold tracking-tight text-primary">Monthly Statement of Accounts</h2>
              <p className="mt-1 text-sm text-gray-500">{summary ? `${summary.branchName} · ${formatStatementDate(summary.fromDate)} – ${formatStatementDate(summary.toDate)}` : "Opening balance, transactions and closing balance by account"}</p>
            </div>
          </div>
          <div className="z-10 flex w-full flex-col gap-2.5 pl-2 sm:flex-row xl:w-auto xl:pl-0">
            <Button type="button" variant="outline" disabled={!report} onClick={() => report && exportCsv(report)} className="h-11 gap-2"><Download size={16} /> Export</Button>
            <Button type="button" variant="outline" disabled={!report} onClick={() => handlePrint()} className="h-11 gap-2"><Printer size={16} /> Print</Button>
          </div>
        </div>
        <Form {...form}>
          <MisReportFilter
            control={form.control}
            isHead={isHead}
            branchName={branchName}
            branchOptions={branchOptions}
            branchLoading={branchLoading}
            loading={loading}
            onSubmit={form.handleSubmit(onShow)}
            fromName="fromDate"
            toName="toDate"
            branchNameField="reportBranchId"
            presets={MIS_REPORT_PRESETS}
            activePreset={activePreset}
            onPreset={onPreset}
          />
        </Form>
        {summary && (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {[
              ["Opening Balance", summary.totalOpeningDebit - summary.totalOpeningCredit],
              ["Total Debit", summary.totalDebit],
              ["Total Credit", summary.totalCredit],
              ["Closing Balance", summary.totalClosingDebit - summary.totalClosingCredit],
            ].map(([label, value]) => (
              <div key={String(label)} className="rounded-xl border border-gray-100 bg-white px-4 py-3 shadow-sm">
                <p className="text-xs font-semibold tracking-wide text-gray-500 uppercase">{label}</p>
                <p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{formatStatementAmount(Number(value))}</p>
              </div>
            ))}
          </div>
        )}
        <div className="page-body-card overflow-hidden">
          <div className="mb-4 flex items-center justify-between">
            <div><h3 className="text-lg font-semibold text-gray-900">Account Statement</h3><p className="text-sm text-gray-500">{report ? `${report.rows.length} account${report.rows.length === 1 ? "" : "s"}` : "Choose a period and select Show"}</p></div>
            {loading && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
          </div>
          {report?.rows.length ? <AccountStatementTable rows={report.rows} /> : <div className="rounded-lg border border-dashed border-gray-200 px-4 py-12 text-center text-sm text-gray-500">{loading ? "Loading statement..." : report ? "No statement data found for this period." : "No report loaded."}</div>}
        </div>
      </div>
      <div ref={printRef} className="hidden bg-white p-4 text-black print:block">
        <h1 className="mb-1 text-xl font-bold">Monthly Statement of Accounts</h1>
        <p className="mb-4 text-sm">{summary?.branchName} · {summary && formatStatementDate(summary.fromDate)} – {summary && formatStatementDate(summary.toDate)}</p>
        {report && <AccountStatementTable rows={report.rows} />}
      </div>
    </>
  );
};

export default MonthlyStatementComponent;
