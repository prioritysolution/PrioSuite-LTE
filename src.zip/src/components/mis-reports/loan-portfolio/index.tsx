"use client";

import { Download, Layers3, Loader2, Printer } from "lucide-react";
import { useRef } from "react";
import { useReactToPrint } from "react-to-print";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import DropdownField from "@/common/formFields/DropdownField";
import MisReportFilter, { MIS_REPORT_PRESETS } from "@/common/reportFilters/MisReportFilter";
import LoanPortfolioTable from "@/common/reportTables/LoanPortfolioTable";
import type { LoanPortfolioProps } from "@/container/mis-reports/loan-portfolio/LoanPortfolioType";

const viewOptions = [{ label: "Branch-wise", value: "branch" }, { label: "Sahayika-wise", value: "sahayika" }];
const money = (value: number) => new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(value || 0);
const pct = (value: number) => `${value.toFixed(2)}%`;
const dateText = (value: string) => value ? value.split("-").reverse().join("-") : "-";

const exportCsv = (report: NonNullable<LoanPortfolioProps["report"]>) => {
  const lines = [["Name", "Code", "Groups", "Members", "Active Loans", "Disbursed", "Outstanding", "Demand", "Collection", "Collection %", "Overdue", "PAR %"], ...report.rows.map((row) => [row.name, row.code, row.activeGroups, row.activeMembers, row.activeLoans, row.disbursedAmount, row.outstanding, row.demand, row.collection, row.collectionPercent, row.overdueAmount, row.parPercent])];
  const csv = lines.map((line) => line.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })); const link = document.createElement("a"); link.href = url; link.download = `loan-portfolio-${report.summary.fromDate}-to-${report.summary.toDate}.csv`; link.click(); URL.revokeObjectURL(url);
};

const LoanPortfolioComponent = ({ form, loading, isHead, branchName, branchOptions, sahayikaOptions, report, onShow, onBranchChange, onPreset, activePreset }: LoanPortfolioProps) => {
  const printRef = useRef<HTMLDivElement>(null);
  const handlePrint = useReactToPrint({ contentRef: printRef, pageStyle: "@page { size: A4 landscape; margin: 8mm; }" });
  const summary = report?.summary;
  return <>
    <div className="page-content print:hidden">
      <div className="page-header-card"><div className="absolute top-0 left-0 h-full w-1.5 bg-primary" /><div className="flex min-w-0 items-start gap-3 pl-2 sm:gap-4"><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary text-white shadow-sm"><Layers3 size={24} /></div><div className="min-w-0"><p className="text-sm font-medium text-gray-500">MIS Report <span className="text-gray-300">›</span> Loan Portfolio</p><h2 className="text-2xl font-bold tracking-tight text-primary">Loan Portfolio</h2><p className="mt-1 text-sm text-gray-500">{summary ? `${summary.branchName} · ${dateText(summary.fromDate)} – ${dateText(summary.toDate)}` : "Monitor portfolio, outstanding and collection performance"}</p></div></div><div className="z-10 flex w-full flex-col gap-2.5 pl-2 sm:flex-row xl:w-auto xl:pl-0"><Button type="button" variant="outline" disabled={!report} onClick={() => report && exportCsv(report)} className="h-11 gap-2"><Download size={16} /> Export</Button><Button type="button" variant="outline" disabled={!report} onClick={() => handlePrint()} className="h-11 gap-2"><Printer size={16} /> Print</Button></div></div>
      <Form {...form}><MisReportFilter control={form.control} isHead={isHead} branchName={branchName} branchOptions={branchOptions} branchLoading={false} loading={loading} onSubmit={form.handleSubmit(onShow)} fromName="fromDate" toName="toDate" branchNameField="reportBranchId" onBranchChange={(value) => onBranchChange(Number(value) || 0)} presets={MIS_REPORT_PRESETS} activePreset={activePreset} onPreset={onPreset}>
        <DropdownField control={form.control} name="sahayikaId" label="Sahayika" options={sahayikaOptions} optionLabelKey="label" optionValueKey="value" disableSorting />
        <DropdownField control={form.control} name="view" label="View" options={viewOptions} optionLabelKey="label" optionValueKey="value" disableSorting />
      </MisReportFilter></Form>
      {summary && <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{[["Active Loans", summary.activeLoans], ["Outstanding", summary.outstanding], ["Demand", summary.demand], ["Collection", summary.collection], ["Collection %", summary.collectionPercent]].map(([label, value]) => <div key={String(label)} className="rounded-xl border border-gray-100 bg-white px-4 py-3 shadow-sm"><p className="text-xs font-semibold tracking-wide text-gray-500 uppercase">{label}</p><p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{label === "Collection %" ? pct(Number(value)) : money(Number(value))}</p></div>)}</div>}
      <div className="page-body-card overflow-hidden"><div className="mb-4 flex items-center justify-between"><div><h3 className="text-lg font-semibold text-gray-900">Loan Portfolio {form.watch("view") === "sahayika" ? "— Sahayika-wise" : "— Branch-wise"}</h3><p className="text-sm text-gray-500">{report ? `${report.rows.length} records` : "Choose filters and select Show"}</p></div>{loading && <Loader2 className="h-5 w-5 animate-spin text-primary" />}</div>{report ? <LoanPortfolioTable rows={report.rows} /> : <div className="rounded-lg border border-dashed border-gray-200 px-4 py-12 text-center text-sm text-gray-500">No report loaded.</div>}</div>
    </div>
    <div ref={printRef} className="hidden bg-white p-4 text-black print:block"><h1 className="mb-1 text-xl font-bold">Loan Portfolio</h1>{report && <LoanPortfolioTable rows={report.rows} />}</div>
  </>;
};
export default LoanPortfolioComponent;
