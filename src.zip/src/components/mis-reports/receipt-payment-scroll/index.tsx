"use client";

import { Download, FileSpreadsheet, Loader2, Printer } from "lucide-react";
import { useReactToPrint } from "react-to-print";
import { useRef } from "react";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import DropdownField from "@/common/formFields/DropdownField";
import MisReportFilter, { MIS_REPORT_PRESETS } from "@/common/reportFilters/MisReportFilter";
import ReceiptPaymentScrollTable from "@/common/reportTables/ReceiptPaymentScrollTable";
import type { ReceiptPaymentScrollProps } from "@/container/mis-reports/receipt-payment-scroll/ReceiptPaymentScrollType";

const typeOptions = [
  { label: "Receipt & Payment", value: "all" },
  { label: "Receipt Only", value: "receipt" },
  { label: "Payment Only", value: "payment" },
];

const formatAmount = (value: number) =>
  new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);

const formatDate = (value: string) => {
  const [year, month, day] = value.split("-");
  return year && month && day ? `${day}-${month}-${year}` : value || "-";
};

const exportCsv = (report: NonNullable<ReceiptPaymentScrollProps["report"]>) => {
  const lines = [
    ["Date", "Voucher No.", "Type", "Sahayika", "Particulars", "Account", "Mode", "Receipt", "Payment", "Balance", "Remarks"],
    ...report.rows.map((row) => [row.date, row.voucherNo, row.voucherType, row.sahayikaName, row.particulars, row.accountName, row.mode, row.receiptAmount, row.paymentAmount, row.runningBalance, row.remarks]),
  ];
  const csv = lines.map((line) => line.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `receipt-payment-scroll-${report.summary.fromDate}-to-${report.summary.toDate}.csv`;
  link.click();
  URL.revokeObjectURL(url);
};

const ReceiptPaymentScrollComponent = ({
  form,
  loading,
  isHead,
  branchName,
  branchOptions,
  branchLoading,
  sahayikaOptions,
  report,
  onShow,
  onPreset,
  activePreset,
}: ReceiptPaymentScrollProps) => {
  const printRef = useRef<HTMLDivElement>(null);
  const handlePrint = useReactToPrint({ contentRef: printRef, pageStyle: "@page { size: A4 landscape; margin: 8mm; }" });
  const summary = report?.summary;
  return (
    <>
      <div className="page-content print:hidden">
        <div className="page-header-card">
          <div className="absolute top-0 left-0 h-full w-1.5 bg-primary" />
          <div className="flex min-w-0 items-start gap-3 pl-2 sm:gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary text-white shadow-sm"><FileSpreadsheet size={24} /></div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-500">MIS Report <span className="text-gray-300">›</span> Receipt Payment Scroll</p>
              <h2 className="text-2xl font-bold tracking-tight text-primary">Receipt Payment Scroll</h2>
              <p className="mt-1 text-sm text-gray-500">{summary ? `${summary.branchName} · ${formatDate(summary.fromDate)} – ${formatDate(summary.toDate)} · ${report?.rows.length || 0} transactions` : "Track receipts, payments and running cash balance"}</p>
            </div>
          </div>
          <div className="z-10 flex w-full flex-col gap-2.5 pl-2 sm:flex-row xl:w-auto xl:pl-0">
            <Button type="button" variant="outline" disabled={!report} onClick={() => report && exportCsv(report)} className="h-11 gap-2"><Download size={16} /> Export</Button>
            <Button type="button" variant="outline" disabled={!report} onClick={() => handlePrint()} className="h-11 gap-2"><Printer size={16} /> Print</Button>
          </div>
        </div>
        <Form {...form}>
          <MisReportFilter
            control={form.control}
            isHead={isHead}
            branchName={branchName}
            branchOptions={branchOptions}
            branchLoading={branchLoading}
            loading={loading}
            onSubmit={form.handleSubmit(onShow)}
            fromName="fromDate"
            toName="toDate"
            branchNameField="reportBranchId"
            onBranchChange={() => form.setValue("sahayikaId", 0)}
            presets={MIS_REPORT_PRESETS}
            activePreset={activePreset}
            onPreset={onPreset}
          >
            <DropdownField
              control={form.control}
              name="sahayikaId"
              label="Sahayika"
              options={sahayikaOptions}
              optionLabelKey="label"
              optionValueKey="value"
              disableSorting
            />
            <DropdownField
              control={form.control}
              name="scrollType"
              label="Scroll Type"
              options={typeOptions}
              optionLabelKey="label"
              optionValueKey="value"
              disableSorting
            />
          </MisReportFilter>
        </Form>
        {summary && (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {[
              ["Opening Balance", summary.openingBalance],
              ["Total Receipts", summary.totalReceipts],
              ["Total Payments", summary.totalPayments],
              ["Closing Balance", summary.closingBalance],
              ["Transactions", summary.receiptCount + summary.paymentCount],
            ].map(([label, value]) => (
              <div key={String(label)} className="rounded-xl border border-gray-100 bg-white px-4 py-3 shadow-sm">
                <p className="text-xs font-semibold tracking-wide text-gray-500 uppercase">{label}</p>
                <p className="mt-1 text-lg font-bold tabular-nums text-gray-900">{label === "Transactions" ? value : formatAmount(Number(value))}</p>
              </div>
            ))}
          </div>
        )}
        <div className="page-body-card overflow-hidden">
          <div className="mb-4 flex items-center justify-between">
            <div><h3 className="text-lg font-semibold text-gray-900">Receipt & Payment Transactions</h3><p className="text-sm text-gray-500">{summary ? `${summary.receiptCount} receipts · ${summary.paymentCount} payments` : "Choose a period and select Show"}</p></div>
            {loading && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
          </div>
          {report ? <ReceiptPaymentScrollTable rows={report.rows} /> : <div className="rounded-lg border border-dashed border-gray-200 px-4 py-12 text-center text-sm text-gray-500">{loading ? "Loading scroll..." : "No report loaded."}</div>}
        </div>
      </div>
      <div ref={printRef} className="hidden bg-white p-4 text-black print:block">
        <h1 className="mb-1 text-xl font-bold">Receipt Payment Scroll</h1>
        <p className="mb-4 text-sm">{summary?.branchName} · {summary && formatDate(summary.fromDate)} – {summary && formatDate(summary.toDate)}</p>
        {report && <ReceiptPaymentScrollTable rows={report.rows} />}
      </div>
    </>
  );
};

export default ReceiptPaymentScrollComponent;
