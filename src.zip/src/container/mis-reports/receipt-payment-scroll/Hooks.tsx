"use client";

import { useEffect, useMemo, useState } from "react";
import { format, isValid, startOfMonth } from "date-fns";
import { useForm, useWatch } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import getCookieData from "@/lib/getCookieData";
import { getDatePresetRange } from "@/common/reportFilters/datePresetRange";
import { useDebouncedRequest } from "@/hooks/useDebouncedRequest";
import { isHeadFlag } from "@/container/profile/ProfileApi";
import type {
  ReceiptPaymentScrollData,
  ReceiptPaymentScrollForm,
  ReceiptPaymentScrollRow,
} from "./ReceiptPaymentScrollType";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

const branchOptions = [
  { label: "All Branches", value: 0 },
  { label: "Head Office", value: 1 },
  { label: "Kolkata Branch", value: 2 },
  { label: "Howrah Branch", value: 3 },
];

const sahayikaByBranch = {
  1: [{ label: "Anita Das", value: 101 }, { label: "Mita Roy", value: 102 }],
  2: [{ label: "Rina Paul", value: 201 }, { label: "Sujata Sen", value: 202 }],
  3: [{ label: "Puja Ghosh", value: 301 }, { label: "Moumita Dey", value: 302 }],
};

const allSahayikaOptions = [
  { label: "All Sahayika", value: 0 },
  ...Object.values(sahayikaByBranch).flat(),
];

const mockTransactions: Omit<ReceiptPaymentScrollRow, "runningBalance">[] = [
  { id: 1, date: "2026-11-01", voucherNo: "RV-0001", voucherType: "Receipt", sahayikaId: 101, sahayikaName: "Anita Das", particulars: "Member savings collection", accountName: "Member Savings", mode: "Cash", receiptAmount: 18500, paymentAmount: 0, remarks: "Morning collection" },
  { id: 2, date: "2026-11-02", voucherNo: "PV-0001", voucherType: "Payment", sahayikaId: 101, sahayikaName: "Anita Das", particulars: "Office stationery purchase", accountName: "Operating Expenses", mode: "Cash", receiptAmount: 0, paymentAmount: 2400, remarks: "" },
  { id: 3, date: "2026-11-03", voucherNo: "RV-0002", voucherType: "Receipt", sahayikaId: 102, sahayikaName: "Mita Roy", particulars: "Loan installment collection", accountName: "Loan Collection", mode: "Bank Transfer", receiptAmount: 32750, paymentAmount: 0, remarks: "NEFT collection" },
  { id: 4, date: "2026-11-05", voucherNo: "PV-0002", voucherType: "Payment", sahayikaId: 201, sahayikaName: "Rina Paul", particulars: "Loan disbursement", accountName: "Loan Disbursement", mode: "Bank Transfer", receiptAmount: 0, paymentAmount: 45000, remarks: "Group loan issue" },
  { id: 5, date: "2026-11-08", voucherNo: "RV-0003", voucherType: "Receipt", sahayikaId: 201, sahayikaName: "Rina Paul", particulars: "Interest income received", accountName: "Interest Income", mode: "Cash", receiptAmount: 8750, paymentAmount: 0, remarks: "" },
  { id: 6, date: "2026-11-10", voucherNo: "PV-0003", voucherType: "Payment", sahayikaId: 202, sahayikaName: "Sujata Sen", particulars: "Staff travel reimbursement", accountName: "Travel Expenses", mode: "Cash", receiptAmount: 0, paymentAmount: 6200, remarks: "Field visit" },
  { id: 7, date: "2026-11-12", voucherNo: "RV-0004", voucherType: "Receipt", sahayikaId: 202, sahayikaName: "Sujata Sen", particulars: "Member savings collection", accountName: "Member Savings", mode: "Cash", receiptAmount: 21600, paymentAmount: 0, remarks: "Weekly collection" },
  { id: 8, date: "2026-11-15", voucherNo: "PV-0004", voucherType: "Payment", sahayikaId: 301, sahayikaName: "Puja Ghosh", particulars: "Utility bill payment", accountName: "Office Expenses", mode: "Bank Transfer", receiptAmount: 0, paymentAmount: 3150, remarks: "Electricity bill" },
  { id: 9, date: "2026-11-18", voucherNo: "RV-0005", voucherType: "Receipt", sahayikaId: 301, sahayikaName: "Puja Ghosh", particulars: "Loan installment collection", accountName: "Loan Collection", mode: "Cash", receiptAmount: 29400, paymentAmount: 0, remarks: "" },
  { id: 10, date: "2026-11-22", voucherNo: "PV-0005", voucherType: "Payment", sahayikaId: 302, sahayikaName: "Moumita Dey", particulars: "Loan disbursement", accountName: "Loan Disbursement", mode: "Bank Transfer", receiptAmount: 0, paymentAmount: 38500, remarks: "Individual loan issue" },
  { id: 11, date: "2026-11-25", voucherNo: "RV-0006", voucherType: "Receipt", sahayikaId: 302, sahayikaName: "Moumita Dey", particulars: "Processing fee received", accountName: "Fee Income", mode: "Cash", receiptAmount: 5400, paymentAmount: 0, remarks: "" },
  { id: 12, date: "2026-11-28", voucherNo: "PV-0006", voucherType: "Payment", sahayikaId: 101, sahayikaName: "Anita Das", particulars: "Office maintenance", accountName: "Maintenance Expenses", mode: "Cash", receiptAmount: 0, paymentAmount: 4800, remarks: "" },
];

const toApiDate = (value: Date | null) =>
  value instanceof Date && isValid(value) ? format(value, "yyyy-MM-dd") : "";

const getMockReport = (
  fromDate: string,
  toDate: string,
  selectedBranch: number,
  branchName: string,
  selectedSahayika: number,
  scrollType: ReceiptPaymentScrollForm["scrollType"],
): ReceiptPaymentScrollData => {
  const filtered = mockTransactions.filter((row) => {
    const inRange = row.date >= fromDate && row.date <= toDate;
    const matchesType =
      scrollType === "all" ||
      (scrollType === "receipt" && row.voucherType === "Receipt") ||
      (scrollType === "payment" && row.voucherType === "Payment");
    const matchesSahayika = !selectedSahayika || row.sahayikaId === selectedSahayika;
    return inRange && matchesType && matchesSahayika;
  });
  let runningBalance = 150000;
  const rows = filtered.map((row) => {
    runningBalance += row.receiptAmount - row.paymentAmount;
    return { ...row, runningBalance };
  });
  const totalReceipts = rows.reduce((total, row) => total + row.receiptAmount, 0);
  const totalPayments = rows.reduce((total, row) => total + row.paymentAmount, 0);
  return {
    message: "Mock data for UI design",
    summary: {
      fromDate,
      toDate,
      branchName: selectedBranch
        ? branchOptions.find((option) => option.value === selectedBranch)?.label || branchName
        : "All Branches",
      openingBalance: 150000,
      totalReceipts,
      totalPayments,
      closingBalance: 150000 + totalReceipts - totalPayments,
      receiptCount: rows.filter((row) => row.voucherType === "Receipt").length,
      paymentCount: rows.filter((row) => row.voucherType === "Payment").length,
    },
    rows,
  };
};

export const useReceiptPaymentScroll = () => {
  const branchName = String(getCookieData("priobank-lite-branch_name") || "Branch");
  const isHead = isHeadFlag(getCookieData("priobank-lite-is_head")) || !getCookieData("priobank-lite-is_head");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<ReceiptPaymentScrollData | null>(null);
  const [activePreset, setActivePreset] = useState<DatePreset | null>("month");
  const schema = yup.object({
    fromDate: yup.mixed<Date>().required("From date is required").test("valid", "From date is required", (value) => value instanceof Date && isValid(value)),
    toDate: yup.mixed<Date>().required("To date is required").test("valid", "To date is required", (value) => value instanceof Date && isValid(value)),
    reportBranchId: yup.mixed<number | "">().optional(),
    sahayikaId: yup.mixed<number | "">().optional(),
    scrollType: yup.mixed<ReceiptPaymentScrollForm["scrollType"]>().required(),
  });
  const form = useForm<ReceiptPaymentScrollForm>({
    mode: "onChange",
    defaultValues: {
      fromDate: startOfMonth(new Date()),
      toDate: new Date(),
      reportBranchId: isHead ? 0 : "",
      sahayikaId: 0,
      scrollType: "all",
    },
    resolver: yupResolver(schema) as never,
  });
  const selectedBranch = Number(useWatch({ control: form.control, name: "reportBranchId" }) || 0);
  const loadReport = async (values: ReceiptPaymentScrollForm) => {
    const fromDate = toApiDate(values.fromDate);
    const toDate = toApiDate(values.toDate);
    if (!fromDate || !toDate) return;
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 350));
    setReport(getMockReport(fromDate, toDate, Number(values.reportBranchId || 0), branchName, Number(values.sahayikaId || 0), values.scrollType));
    setLoading(false);
  };
  const onShow = useDebouncedRequest(loadReport);
  const onPreset = (preset: DatePreset) => {
    const { from, to } = getDatePresetRange(preset);
    setActivePreset(preset);
    form.setValue("fromDate", from, { shouldValidate: true, shouldDirty: true });
    form.setValue("toDate", to, { shouldValidate: true, shouldDirty: true });
    onShow({ ...form.getValues(), fromDate: from, toDate: to });
  };
  useEffect(() => {
    onShow(form.getValues());
    // Load the current month's mock scroll once after mounting.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    form,
    loading,
    isHead,
    branchName,
    branchOptions: useMemo(() => (isHead ? branchOptions : []), [isHead]),
    sahayikaOptions: useMemo(() => (
      selectedBranch
        ? [{ label: "All Sahayika", value: 0 }, ...(sahayikaByBranch[selectedBranch as keyof typeof sahayikaByBranch] || [])]
        : allSahayikaOptions
    ), [selectedBranch]),
    branchLoading: false,
    report,
    onShow,
    onPreset,
    activePreset,
  };
};
