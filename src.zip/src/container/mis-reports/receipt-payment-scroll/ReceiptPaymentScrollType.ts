import type { UseFormReturn } from "react-hook-form";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

export type ScrollType = "all" | "receipt" | "payment";

export interface ReceiptPaymentScrollForm {
  fromDate: Date | null;
  toDate: Date | null;
  reportBranchId: number | "";
  sahayikaId: number | "";
  scrollType: ScrollType;
}

export interface ReceiptPaymentScrollRow {
  id: number;
  date: string;
  voucherNo: string;
  voucherType: string;
  sahayikaId: number;
  sahayikaName: string;
  particulars: string;
  accountName: string;
  mode: string;
  receiptAmount: number;
  paymentAmount: number;
  runningBalance: number;
  remarks: string;
}

export interface ReceiptPaymentScrollSummary {
  fromDate: string;
  toDate: string;
  branchName: string;
  openingBalance: number;
  totalReceipts: number;
  totalPayments: number;
  closingBalance: number;
  receiptCount: number;
  paymentCount: number;
}

export interface ReceiptPaymentScrollData {
  message: string;
  summary: ReceiptPaymentScrollSummary;
  rows: ReceiptPaymentScrollRow[];
}

export interface ReceiptPaymentScrollProps {
  form: UseFormReturn<ReceiptPaymentScrollForm>;
  loading: boolean;
  isHead: boolean;
  branchName: string;
  branchOptions: { label: string; value: number }[];
  branchLoading: boolean;
  sahayikaOptions: { label: string; value: number }[];
  report: ReceiptPaymentScrollData | null;
  onShow: (values: ReceiptPaymentScrollForm) => void;
  onPreset: (preset: DatePreset) => void;
  activePreset: DatePreset | null;
}
