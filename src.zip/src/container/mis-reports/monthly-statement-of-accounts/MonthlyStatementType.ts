import type { UseFormReturn } from "react-hook-form";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

export interface MonthlyStatementForm {
  fromDate: Date | null;
  toDate: Date | null;
  reportBranchId: number | "";
}

export interface MonthlyStatementRow {
  accountId: number;
  accountCode: string;
  accountName: string;
  category: string;
  openingDebit: number;
  openingCredit: number;
  debit: number;
  credit: number;
  closingDebit: number;
  closingCredit: number;
}

export interface MonthlyStatementSummary {
  fromDate: string;
  toDate: string;
  branchName: string;
  totalOpeningDebit: number;
  totalOpeningCredit: number;
  totalDebit: number;
  totalCredit: number;
  totalClosingDebit: number;
  totalClosingCredit: number;
}

export interface MonthlyStatementData {
  message: string;
  summary: MonthlyStatementSummary;
  rows: MonthlyStatementRow[];
}

export interface MonthlyStatementProps {
  form: UseFormReturn<MonthlyStatementForm>;
  loading: boolean;
  isHead: boolean;
  branchName: string;
  branchOptions: { label: string; value: number }[];
  branchLoading: boolean;
  report: MonthlyStatementData | null;
  onShow: (values: MonthlyStatementForm) => void;
  onPreset: (preset: DatePreset) => void;
  activePreset: DatePreset | null;
}
