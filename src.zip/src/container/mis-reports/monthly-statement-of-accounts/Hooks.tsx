"use client";

import { useEffect, useMemo, useState } from "react";
import { format, isValid, startOfMonth } from "date-fns";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import getCookieData from "@/lib/getCookieData";
import { getDatePresetRange } from "@/common/reportFilters/datePresetRange";
import { useDebouncedRequest } from "@/hooks/useDebouncedRequest";
import { isHeadFlag } from "@/container/profile/ProfileApi";
import type { MonthlyStatementData, MonthlyStatementForm } from "./MonthlyStatementType";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

const toApiDate = (value: Date | null) =>
  value instanceof Date && isValid(value) ? format(value, "yyyy-MM-dd") : "";

const mockBranches = [
  { label: "All Branches", value: 0 },
  { label: "Head Office", value: 1 },
  { label: "Kolkata Branch", value: 2 },
  { label: "Howrah Branch", value: 3 },
];

const createMockReport = (
  fromDate: string,
  toDate: string,
  selectedBranch: number,
  branchName: string,
): MonthlyStatementData => {
  const rows = [
    { accountId: 1, accountCode: "1001", accountName: "Cash in Hand", category: "Assets", openingDebit: 125000, openingCredit: 0, debit: 85200, credit: 64000 },
    { accountId: 2, accountCode: "1002", accountName: "Bank Account", category: "Assets", openingDebit: 425000, openingCredit: 0, debit: 215000, credit: 182500 },
    { accountId: 3, accountCode: "2001", accountName: "Member Savings", category: "Liabilities", openingDebit: 0, openingCredit: 310000, debit: 45000, credit: 87500 },
    { accountId: 4, accountCode: "3001", accountName: "Loan Disbursement", category: "Expenses", openingDebit: 185000, openingCredit: 0, debit: 325000, credit: 0 },
    { accountId: 5, accountCode: "4001", accountName: "Interest Income", category: "Income", openingDebit: 0, openingCredit: 92000, debit: 0, credit: 47500 },
    { accountId: 6, accountCode: "5001", accountName: "Operating Expenses", category: "Expenses", openingDebit: 56000, openingCredit: 0, debit: 28500, credit: 0 },
  ].map((row) => ({
    ...row,
    closingDebit: row.openingDebit + row.debit,
    closingCredit: row.openingCredit + row.credit,
  }));
  const sum = (key: keyof (typeof rows)[number]) =>
    rows.reduce((total, row) => total + Number(row[key] || 0), 0);
  return {
    message: "Mock data for UI design",
    summary: {
      fromDate,
      toDate,
      branchName: selectedBranch ? mockBranches.find((item) => item.value === selectedBranch)?.label || branchName : "All Branches",
      totalOpeningDebit: sum("openingDebit"),
      totalOpeningCredit: sum("openingCredit"),
      totalDebit: sum("debit"),
      totalCredit: sum("credit"),
      totalClosingDebit: sum("closingDebit"),
      totalClosingCredit: sum("closingCredit"),
    },
    rows,
  };
};

export const useMonthlyStatement = () => {
  const orgId = Number(getCookieData("priobank-lite-org_id") || 0);
  const branchId = Number(getCookieData("priobank-lite-branch_id") || 0);
  const branchName = String(getCookieData("priobank-lite-branch_name") || "Branch");
  const isHead = isHeadFlag(getCookieData("priobank-lite-is_head")) || !getCookieData("priobank-lite-is_head");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<MonthlyStatementData | null>(null);
  const [activePreset, setActivePreset] = useState<DatePreset | null>("month");

  const schema = yup.object({
    fromDate: yup.mixed<Date>().required("From date is required").test("valid", "From date is required", (value) => value instanceof Date && isValid(value)),
    toDate: yup.mixed<Date>().required("To date is required").test("valid", "To date is required", (value) => value instanceof Date && isValid(value)),
    reportBranchId: yup.mixed<number | "">().optional(),
  });
  const methods = useForm<MonthlyStatementForm>({
    mode: "onChange",
    defaultValues: { fromDate: startOfMonth(new Date()), toDate: new Date(), reportBranchId: isHead ? 0 : "" },
    resolver: yupResolver(schema) as never,
  });
  const branchOptions = useMemo(() => (isHead ? mockBranches : []), [isHead]);
  const loadReport = async (values: MonthlyStatementForm) => {
    const fromDate = toApiDate(values.fromDate);
    const toDate = toApiDate(values.toDate);
    if (!fromDate || !toDate) return;
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 350));
    setReport(createMockReport(fromDate, toDate, Number(values.reportBranchId || 0), branchName));
    setLoading(false);
  };
  const requestReport = useDebouncedRequest(loadReport);
  const onPreset = (preset: DatePreset) => {
    const { from, to } = getDatePresetRange(preset);
    setActivePreset(preset);
    methods.setValue("fromDate", from, { shouldValidate: true, shouldDirty: true });
    methods.setValue("toDate", to, { shouldValidate: true, shouldDirty: true });
    requestReport({ ...methods.getValues(), fromDate: from, toDate: to });
  };
  useEffect(() => {
    requestReport(methods.getValues());
    // Load the current month's statement once after mounting.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    form: methods,
    loading,
    isHead,
    branchName,
    branchOptions,
    branchLoading: false,
    report,
    onShow: requestReport,
    onPreset,
    activePreset,
  };
};
