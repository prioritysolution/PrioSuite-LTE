import { doGetApiCall } from "@/lib/axios";
import { endPoints } from "@/services/apiEndpoints";
import type {
  MonthlyStatementData,
  MonthlyStatementRow,
  MonthlyStatementSummary,
} from "./MonthlyStatementType";

const numberValue = (value: unknown) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const textValue = (value: unknown) =>
  value === null || value === undefined ? "" : String(value);

const firstValue = (row: Record<string, unknown>, keys: string[]) => {
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== null) return row[key];
  }
  return 0;
};

const mapRow = (raw: unknown): MonthlyStatementRow => {
  const row = (raw || {}) as Record<string, unknown>;
  return {
    accountId: numberValue(firstValue(row, ["Account_Id", "account_id", "id"])),
    accountCode: textValue(firstValue(row, ["Account_Code", "account_code", "code"])),
    accountName: textValue(
      firstValue(row, ["Ledger_Name", "Account_Name", "account_name", "name"]),
    ),
    category: textValue(firstValue(row, ["Cate_Desc", "Category", "category"])),
    openingDebit: numberValue(firstValue(row, ["Opening_Debit", "opening_debit", "Op_Dr"])),
    openingCredit: numberValue(firstValue(row, ["Opening_Credit", "opening_credit", "Op_Cr"])),
    debit: numberValue(firstValue(row, ["Debit", "debit", "Dr"])),
    credit: numberValue(firstValue(row, ["Credit", "credit", "Cr"])),
    closingDebit: numberValue(firstValue(row, ["Closing_Debit", "closing_debit", "Cl_Dr"])),
    closingCredit: numberValue(firstValue(row, ["Closing_Credit", "closing_credit", "Cl_Cr"])),
  };
};

const mapSummary = (raw: unknown, rows: MonthlyStatementRow[]): MonthlyStatementSummary => {
  const summary = (raw || {}) as Record<string, unknown>;
  const total = (keys: string[], fallback: number) =>
    numberValue(firstValue(summary, keys)) || fallback;
  return {
    fromDate: textValue(firstValue(summary, ["From_Date", "from_date"])),
    toDate: textValue(firstValue(summary, ["To_Date", "to_date"])),
    branchName: textValue(firstValue(summary, ["Branch_Name", "branch_name"])) || "Branch",
    totalOpeningDebit: total(["Total_Opening_Debit", "total_opening_debit"], rows.reduce((sum, row) => sum + row.openingDebit, 0)),
    totalOpeningCredit: total(["Total_Opening_Credit", "total_opening_credit"], rows.reduce((sum, row) => sum + row.openingCredit, 0)),
    totalDebit: total(["Total_Debit", "total_debit"], rows.reduce((sum, row) => sum + row.debit, 0)),
    totalCredit: total(["Total_Credit", "total_credit"], rows.reduce((sum, row) => sum + row.credit, 0)),
    totalClosingDebit: total(["Total_Closing_Debit", "total_closing_debit"], rows.reduce((sum, row) => sum + row.closingDebit, 0)),
    totalClosingCredit: total(["Total_Closing_Credit", "total_closing_credit"], rows.reduce((sum, row) => sum + row.closingCredit, 0)),
  };
};

export const mapMonthlyStatement = (response: unknown): MonthlyStatementData | null => {
  const body = (response || {}) as Record<string, unknown>;
  const details = body.details;
  const rowsSource: unknown[] = Array.isArray(details)
    ? details
    : Array.isArray((details as Record<string, unknown> | null)?.Rows)
      ? ((details as Record<string, unknown>).Rows as unknown[])
      : Array.isArray(body.data)
        ? body.data
        : [];
  const rows = rowsSource.map(mapRow);
  const summarySource =
    !Array.isArray(details) && details && typeof details === "object"
      ? (details as Record<string, unknown>).Summary
      : body.summary;
  return {
    message: textValue(body.message),
    summary: mapSummary(summarySource, rows),
    rows,
  };
};

export const getMonthlyStatementAPI = (
  orgId: number,
  branchId: number,
  fromDate: string,
  toDate: string,
  reportBranchId?: number | null,
) =>
  doGetApiCall({
    url: endPoints.getMonthlyStatementOfAccounts(
      orgId,
      branchId,
      fromDate,
      toDate,
      reportBranchId,
    ),
  });

export const formatStatementAmount = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value || 0);

export const formatStatementDate = (value: string) => {
  const [year, month, day] = String(value || "").split("-");
  return year && month && day ? `${day}-${month}-${year}` : value || "-";
};
