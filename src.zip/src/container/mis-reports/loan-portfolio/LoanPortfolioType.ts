import type { UseFormReturn } from "react-hook-form";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

export type PortfolioView = "branch" | "sahayika";

export interface LoanPortfolioForm {
  fromDate: Date | null;
  toDate: Date | null;
  reportBranchId: number | "";
  sahayikaId: number | "";
  view: PortfolioView;
}

export interface LoanPortfolioRow {
  id: number;
  name: string;
  code: string;
  branchName: string;
  sahayikaName: string;
  activeGroups: number;
  activeMembers: number;
  activeLoans: number;
  disbursedAmount: number;
  outstanding: number;
  demand: number;
  collection: number;
  collectionPercent: number;
  overdueAmount: number;
  parPercent: number;
}

export interface LoanPortfolioSummary {
  fromDate: string;
  toDate: string;
  branchName: string;
  activeLoans: number;
  activeMembers: number;
  outstanding: number;
  demand: number;
  collection: number;
  collectionPercent: number;
  overdueAmount: number;
}

export interface LoanPortfolioData {
  summary: LoanPortfolioSummary;
  rows: LoanPortfolioRow[];
}

export interface LoanPortfolioProps {
  form: UseFormReturn<LoanPortfolioForm>;
  loading: boolean;
  isHead: boolean;
  branchName: string;
  branchOptions: { label: string; value: number }[];
  sahayikaOptions: { label: string; value: number }[];
  report: LoanPortfolioData | null;
  onShow: (values: LoanPortfolioForm) => void;
  onBranchChange: (value: number) => void;
  onPreset: (preset: DatePreset) => void;
  activePreset: DatePreset | null;
}
