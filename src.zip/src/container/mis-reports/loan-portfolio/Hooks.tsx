"use client";

import { useEffect, useMemo, useState } from "react";
import { format, isValid, startOfMonth } from "date-fns";
import { useForm, useWatch } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import getCookieData from "@/lib/getCookieData";
import { useDebouncedRequest } from "@/hooks/useDebouncedRequest";
import { isHeadFlag } from "@/container/profile/ProfileApi";
import { getDatePresetRange } from "@/common/reportFilters/datePresetRange";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";
import type { LoanPortfolioData, LoanPortfolioForm, LoanPortfolioRow } from "./LoanPortfolioType";

const branches = [
  { label: "All Branches", value: 0 },
  { label: "Head Office", value: 1 },
  { label: "Kolkata Branch", value: 2 },
  { label: "Howrah Branch", value: 3 },
];
const sahayikaByBranch: Record<number, { label: string; value: number }[]> = {
  1: [{ label: "Anita Das", value: 101 }, { label: "Mita Roy", value: 102 }],
  2: [{ label: "Rina Paul", value: 201 }, { label: "Sujata Sen", value: 202 }],
  3: [{ label: "Puja Ghosh", value: 301 }, { label: "Moumita Dey", value: 302 }],
};
const allSahayika = [{ label: "All Sahayika", value: 0 }, ...Object.values(sahayikaByBranch).flat()];

const rows: LoanPortfolioRow[] = [
  { id: 1, name: "Head Office", code: "HO-001", branchName: "Head Office", sahayikaName: "Anita Das", activeGroups: 24, activeMembers: 286, activeLoans: 198, disbursedAmount: 4850000, outstanding: 3265000, demand: 582000, collection: 545800, collectionPercent: 93.78, overdueAmount: 36200, parPercent: 4.12 },
  { id: 2, name: "Head Office", code: "HO-002", branchName: "Head Office", sahayikaName: "Mita Roy", activeGroups: 19, activeMembers: 224, activeLoans: 164, disbursedAmount: 3920000, outstanding: 2580000, demand: 468000, collection: 451200, collectionPercent: 96.41, overdueAmount: 16800, parPercent: 2.85 },
  { id: 3, name: "Kolkata Branch", code: "KOL-001", branchName: "Kolkata Branch", sahayikaName: "Rina Paul", activeGroups: 31, activeMembers: 372, activeLoans: 267, disbursedAmount: 6740000, outstanding: 4915000, demand: 785000, collection: 718300, collectionPercent: 91.50, overdueAmount: 66700, parPercent: 5.34 },
  { id: 4, name: "Kolkata Branch", code: "KOL-002", branchName: "Kolkata Branch", sahayikaName: "Sujata Sen", activeGroups: 26, activeMembers: 318, activeLoans: 229, disbursedAmount: 5210000, outstanding: 3650000, demand: 624000, collection: 590600, collectionPercent: 94.65, overdueAmount: 33400, parPercent: 3.91 },
  { id: 5, name: "Howrah Branch", code: "HOW-001", branchName: "Howrah Branch", sahayikaName: "Puja Ghosh", activeGroups: 22, activeMembers: 265, activeLoans: 187, disbursedAmount: 4380000, outstanding: 2980000, demand: 514000, collection: 471800, collectionPercent: 91.79, overdueAmount: 42200, parPercent: 5.72 },
  { id: 6, name: "Howrah Branch", code: "HOW-002", branchName: "Howrah Branch", sahayikaName: "Moumita Dey", activeGroups: 18, activeMembers: 209, activeLoans: 148, disbursedAmount: 3560000, outstanding: 2310000, demand: 427000, collection: 403600, collectionPercent: 94.52, overdueAmount: 23400, parPercent: 3.64 },
];
const toDate = (value: Date | null) => value instanceof Date && isValid(value) ? format(value, "yyyy-MM-dd") : "";

const makeReport = (form: LoanPortfolioForm): LoanPortfolioData => {
  const selectedBranch = Number(form.reportBranchId || 0);
  const selectedCo = Number(form.sahayikaId || 0);
  const filtered = rows.filter((row) =>
    (!selectedBranch || row.branchName === branches.find((item) => item.value === selectedBranch)?.label) &&
    (!selectedCo || row.sahayikaName === allSahayika.find((item) => item.value === selectedCo)?.label),
  );
  const source = form.view === "sahayika" ? filtered : filtered.reduce<LoanPortfolioRow[]>((result, row) => {
    const existing = result.find((item) => item.branchName === row.branchName);
    if (!existing) result.push({ ...row, id: row.id, name: row.branchName, code: row.branchName.slice(0, 3).toUpperCase(), sahayikaName: "All Sahayika" });
    else Object.assign(existing, {
      activeGroups: existing.activeGroups + row.activeGroups, activeMembers: existing.activeMembers + row.activeMembers,
      activeLoans: existing.activeLoans + row.activeLoans, disbursedAmount: existing.disbursedAmount + row.disbursedAmount,
      outstanding: existing.outstanding + row.outstanding, demand: existing.demand + row.demand, collection: existing.collection + row.collection,
      overdueAmount: existing.overdueAmount + row.overdueAmount,
    });
    return result;
  }, []);
  const normalized = source.map((row) => ({ ...row, collectionPercent: row.demand ? (row.collection / row.demand) * 100 : 0 }));
  const total = (key: keyof LoanPortfolioRow) => normalized.reduce((sum, row) => sum + Number(row[key] || 0), 0);
  return {
    summary: {
      fromDate: toDate(form.fromDate), toDate: toDate(form.toDate),
      branchName: selectedBranch ? branches.find((item) => item.value === selectedBranch)?.label || "Branch" : "All Branches",
      activeLoans: total("activeLoans"), activeMembers: total("activeMembers"), outstanding: total("outstanding"),
      demand: total("demand"), collection: total("collection"), collectionPercent: total("demand") ? (total("collection") / total("demand")) * 100 : 0, overdueAmount: total("overdueAmount"),
    },
    rows: normalized,
  };
};

export const useLoanPortfolio = () => {
  const branchName = String(getCookieData("priobank-lite-branch_name") || "Branch");
  const rawHead = getCookieData("priobank-lite-is_head");
  const isHead = isHeadFlag(rawHead) || !rawHead;
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<LoanPortfolioData | null>(null);
  const [activePreset, setActivePreset] = useState<DatePreset | null>("month");
  const form = useForm<LoanPortfolioForm>({
    defaultValues: { fromDate: startOfMonth(new Date()), toDate: new Date(), reportBranchId: isHead ? 0 : "", sahayikaId: 0, view: "branch" },
    resolver: yupResolver(yup.object({ fromDate: yup.mixed<Date>().required(), toDate: yup.mixed<Date>().required(), reportBranchId: yup.mixed<number | "">(), sahayikaId: yup.mixed<number | "">(), view: yup.mixed<"branch" | "sahayika">().required() })) as never,
  });
  const selectedBranch = Number(useWatch({ control: form.control, name: "reportBranchId" }) || 0);
  const load = async (values: LoanPortfolioForm) => {
    setLoading(true); await new Promise((resolve) => setTimeout(resolve, 350)); setReport(makeReport(values)); setLoading(false);
  };
  const onShow = useDebouncedRequest(load);
  const onBranchChange = (value: number) => { form.setValue("reportBranchId", value); form.setValue("sahayikaId", 0); };
  const onPreset = (preset: DatePreset) => {
    const { from, to } = getDatePresetRange(preset);
    setActivePreset(preset); form.setValue("fromDate", from); form.setValue("toDate", to); onShow({ ...form.getValues(), fromDate: from, toDate: to });
  };
  useEffect(() => { onShow(form.getValues()); /* initial mock report */ // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return { form, loading, isHead, branchName, branchOptions: isHead ? branches : [], sahayikaOptions: selectedBranch ? [{ label: "All Sahayika", value: 0 }, ...(sahayikaByBranch[selectedBranch] || [])] : allSahayika, report, onShow, onBranchChange, onPreset, activePreset };
};
