import type { UseFormReturn } from "react-hook-form";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";

export type ParView = "branch" | "sahayika";

export interface DefaultParCalculationForm {
  fromDate: Date | null;
  toDate: Date | null;
  reportBranchId: number | "";
  sahayikaId: number | "";
  view: ParView;
}

export interface DefaultParCalculationRow {
  id: number;
  name: string;
  code: string;
  branchName: string;
  sahayikaName: string;
  activeLoans: number;
  outstanding: number;
  par1To30: number;
  par31To60: number;
  par61To90: number;
  parAbove90: number;
  parAmount: number;
  parPercent: number;
}

export interface DefaultParCalculationSummary {
  fromDate: string;
  toDate: string;
  branchName: string;
  activeLoans: number;
  outstanding: number;
  parAmount: number;
  parPercent: number;
}

export interface DefaultParCalculationData {
  summary: DefaultParCalculationSummary;
  rows: DefaultParCalculationRow[];
}

export interface DefaultParCalculationProps {
  form: UseFormReturn<DefaultParCalculationForm>;
  loading: boolean;
  isHead: boolean;
  branchName: string;
  branchOptions: { label: string; value: number }[];
  sahayikaOptions: { label: string; value: number }[];
  report: DefaultParCalculationData | null;
  onShow: (values: DefaultParCalculationForm) => void;
  onBranchChange: (value: number) => void;
  onPreset: (preset: DatePreset) => void;
  activePreset: DatePreset | null;
}
