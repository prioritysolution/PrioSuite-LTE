"use client";

import { useEffect, useState } from "react";
import { format, isValid, startOfMonth } from "date-fns";
import { useForm, useWatch } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import getCookieData from "@/lib/getCookieData";
import { useDebouncedRequest } from "@/hooks/useDebouncedRequest";
import { isHeadFlag } from "@/container/profile/ProfileApi";
import { getDatePresetRange } from "@/common/reportFilters/datePresetRange";
import type { DatePreset } from "@/container/mis-reports/co-perfromance/CoPerformanceType";
import type {
  DefaultParCalculationData,
  DefaultParCalculationForm,
  DefaultParCalculationRow,
} from "./DefaultParCalculationType";

const branches = [
  { label: "All Branches", value: 0 },
  { label: "Head Office", value: 1 },
  { label: "Kolkata Branch", value: 2 },
  { label: "Howrah Branch", value: 3 },
];

const sahayikaByBranch: Record<number, { label: string; value: number }[]> = {
  1: [{ label: "Anita Das", value: 101 }, { label: "Mita Roy", value: 102 }],
  2: [{ label: "Rina Paul", value: 201 }, { label: "Sujata Sen", value: 202 }],
  3: [{ label: "Puja Ghosh", value: 301 }, { label: "Moumita Dey", value: 302 }],
};

const allSahayika = [
  { label: "All Sahayika", value: 0 },
  ...Object.values(sahayikaByBranch).flat(),
];

const sourceRows: DefaultParCalculationRow[] = [
  { id: 1, name: "Anita Das", code: "HO-001", branchName: "Head Office", sahayikaName: "Anita Das", activeLoans: 198, outstanding: 3265000, par1To30: 84200, par31To60: 46200, par61To90: 28500, parAbove90: 17800, parAmount: 176700, parPercent: 5.41 },
  { id: 2, name: "Mita Roy", code: "HO-002", branchName: "Head Office", sahayikaName: "Mita Roy", activeLoans: 164, outstanding: 2580000, par1To30: 53200, par31To60: 28400, par61To90: 19600, parAbove90: 11200, parAmount: 112400, parPercent: 4.36 },
  { id: 3, name: "Rina Paul", code: "KOL-001", branchName: "Kolkata Branch", sahayikaName: "Rina Paul", activeLoans: 267, outstanding: 4915000, par1To30: 126500, par31To60: 78400, par61To90: 46800, parAbove90: 32600, parAmount: 284300, parPercent: 5.78 },
  { id: 4, name: "Sujata Sen", code: "KOL-002", branchName: "Kolkata Branch", sahayikaName: "Sujata Sen", activeLoans: 229, outstanding: 3650000, par1To30: 94200, par31To60: 51700, par61To90: 32400, parAbove90: 22400, parAmount: 200700, parPercent: 5.50 },
  { id: 5, name: "Puja Ghosh", code: "HOW-001", branchName: "Howrah Branch", sahayikaName: "Puja Ghosh", activeLoans: 187, outstanding: 2980000, par1To30: 79500, par31To60: 42600, par61To90: 25100, parAbove90: 18900, parAmount: 166100, parPercent: 5.57 },
  { id: 6, name: "Moumita Dey", code: "HOW-002", branchName: "Howrah Branch", sahayikaName: "Moumita Dey", activeLoans: 148, outstanding: 2310000, par1To30: 56800, par31To60: 31500, par61To90: 19300, parAbove90: 14300, parAmount: 121900, parPercent: 5.28 },
];

const toDateText = (value: Date | null) =>
  value instanceof Date && isValid(value) ? format(value, "yyyy-MM-dd") : "";

const makeReport = (form: DefaultParCalculationForm): DefaultParCalculationData => {
  const selectedBranch = Number(form.reportBranchId || 0);
  const selectedSahayika = Number(form.sahayikaId || 0);
  const filtered = sourceRows.filter((row) =>
    (!selectedBranch || row.branchName === branches.find((item) => item.value === selectedBranch)?.label) &&
    (!selectedSahayika || row.sahayikaName === allSahayika.find((item) => item.value === selectedSahayika)?.label),
  );
  const rows = form.view === "sahayika"
    ? filtered
    : filtered.reduce<DefaultParCalculationRow[]>((result, row) => {
      const existing = result.find((item) => item.branchName === row.branchName);
      if (!existing) {
        result.push({
          ...row,
          name: row.branchName,
          code: row.branchName.slice(0, 3).toUpperCase(),
          sahayikaName: "All Sahayika",
        });
      } else {
        existing.activeLoans += row.activeLoans;
        existing.outstanding += row.outstanding;
        existing.par1To30 += row.par1To30;
        existing.par31To60 += row.par31To60;
        existing.par61To90 += row.par61To90;
        existing.parAbove90 += row.parAbove90;
        existing.parAmount += row.parAmount;
      }
      return result;
    }, []).map((row) => ({ ...row, parPercent: row.outstanding ? (row.parAmount / row.outstanding) * 100 : 0 }));
  const total = (key: keyof DefaultParCalculationRow) =>
    rows.reduce((sum, row) => sum + Number(row[key] || 0), 0);
  return {
    summary: {
      fromDate: toDateText(form.fromDate),
      toDate: toDateText(form.toDate),
      branchName: selectedBranch ? branches.find((item) => item.value === selectedBranch)?.label || "Branch" : "All Branches",
      activeLoans: total("activeLoans"),
      outstanding: total("outstanding"),
      parAmount: total("parAmount"),
      parPercent: total("outstanding") ? (total("parAmount") / total("outstanding")) * 100 : 0,
    },
    rows,
  };
};

export const useDefaultParCalculation = () => {
  const branchName = String(getCookieData("priobank-lite-branch_name") || "Branch");
  const rawHead = getCookieData("priobank-lite-is_head");
  const isHead = isHeadFlag(rawHead) || !rawHead;
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<DefaultParCalculationData | null>(null);
  const [activePreset, setActivePreset] = useState<DatePreset | null>("month");
  const form = useForm<DefaultParCalculationForm>({
    defaultValues: {
      fromDate: startOfMonth(new Date()),
      toDate: new Date(),
      reportBranchId: isHead ? 0 : "",
      sahayikaId: 0,
      view: "branch",
    },
    resolver: yupResolver(yup.object({
      fromDate: yup.mixed<Date>().required(),
      toDate: yup.mixed<Date>().required(),
      reportBranchId: yup.mixed<number | "">(),
      sahayikaId: yup.mixed<number | "">(),
      view: yup.mixed<"branch" | "sahayika">().required(),
    })) as never,
  });
  const selectedBranch = Number(useWatch({ control: form.control, name: "reportBranchId" }) || 0);
  const load = async (values: DefaultParCalculationForm) => {
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 350));
    setReport(makeReport(values));
    setLoading(false);
  };
  const onShow = useDebouncedRequest(load);
  const onBranchChange = (value: number) => {
    form.setValue("reportBranchId", value);
    form.setValue("sahayikaId", 0);
  };
  const onPreset = (preset: DatePreset) => {
    const { from, to } = getDatePresetRange(preset);
    setActivePreset(preset);
    form.setValue("fromDate", from, { shouldValidate: true, shouldDirty: true });
    form.setValue("toDate", to, { shouldValidate: true, shouldDirty: true });
    onShow({ ...form.getValues(), fromDate: from, toDate: to });
  };
  useEffect(() => {
    onShow(form.getValues());
    // Load the current month's mock report once after mounting.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    form,
    loading,
    isHead,
    branchName,
    branchOptions: isHead ? branches : [],
    sahayikaOptions: selectedBranch
      ? [{ label: "All Sahayika", value: 0 }, ...(sahayikaByBranch[selectedBranch] || [])]
      : allSahayika,
    report,
    onShow,
    onBranchChange,
    onPreset,
    activePreset,
  };
};
